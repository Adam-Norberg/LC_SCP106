# SCP-106
*SCP-106 has breached containment.*
*Going alone is strictly forbidden.*

## Abilities
<details>
<summary>*[Redacted]*</summary>
Abilities are visible on Github / Source, to avoid spoilers.
</details>

## Installation
Place both files inside BepInEx/Plugins

## Known Issues
<p>
- Outside navigation is flawed, and is disabled by code until it can be fixed.<br>
- The mod "OopsAllFlooded", as it floods the interior/facility it also floods the Pocket Dimension.
</p>

## Credits
- The Model & inherited Animations for "SCP-106" (https://skfb.ly/o7zoA) by ThatJamGuy is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/). *I, the author of this mod (Dackie), have made some alterations and modifications to existing animations as well as new animation(s) not originally made by the creator (ThatJamGuy) of the model.*
- 'SCP - Containment Breach' for the Sound Effects, Music, and Inspiration, along with the Character SCP-106 created by "Dr Gears".
- Hamunii (and all people listed in their credits!) for the Template - https://github.com/Hamunii/LC-ExampleEnemy

## Afterwords
As this is my first mod and time with Unity, please report any glitches or bugs that you may experience to me. More functionalities are planned for the future. Feel free to use any of the code for this mod in your own.