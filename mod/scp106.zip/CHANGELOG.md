## 3.0.1
- Fixed broken behaviour from previous version.

## 3.0.0
- Pocket Dimension added.
- New ability added for SCP-106.
- New behaviour(s) added.
- Adjustments made to existing behaviour.
- Some sound effects added, some older replaced.
- ... and more.
- Patched for V62 release of Lethal Company.
- (Outside behaviour is flawed and thus disabled until further)

## 2.0.0
- Blunt objects have been found useful in aiding crewmates in the event of direct contact with SCP-106.
- SCP-106 has been reported exiting facilities located within the Company's area of operations.
- Signs of corrosion has been spotted on the interior of empty, returning vessels. Likely due to crewmember's negligence in operating the Blast Doors when necessary.
- Further reading suggests that SCP-106 often torments their victim before killing them.
- ... Experimental and proprietary systems have been made available to crewmembers for increasing/decreasing the likelyhood for all the events above.

## 1.0.1
- Patched for V50 release of Lethal Company.

## 1.0.0

- Initial release